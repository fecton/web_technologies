<!DOCTYPE html>
<html>
<body>
    <div class="center-menu">
        <img src="img/backgrounds/header-2.jpg" alt="Рулетка">
        <div class="back">
            <p id="welcome">WELCOME TO THE GRAND</p>
            <p id="words">
                Why should you play at the Grand Online Casino?<br> 
                To have fun and win big money of course!<br>  
                Our loyal members love playing the more than 40<br>
                games and getting paid fast. Try the games for<br> 
                free and for as long as you like. Grand Online<br>
                has blackjack, poker, slots, craps, roulette and<br>
                many others to choose from. When you’re ready<br> 
                for real cash winnings, the Grand’s generous sign<br>
                up bonus will help you get in on the action.<br> 
                <br>
                The benefits of membership don’t stop there.<br> 
                If you have any questions you can access<br>
                24-hour toll-free telephone, email, and live<br> 
                customer support for a fast, friendly response.<br>
                The Grand Online Casino guarantees your privacy<br>
                and uses 128-bit encryption to ensure the safety<br> 
                of each and every financial transaction.<br>
                <br>
                Are the games fair? You bet they are! A Random<br>
                Number Generator controls the outcome of every<br>
                game at the Grand Online Casino. The games<br>
                frequently undergo rigorous testing for reliability<br> 
                by an independent third-party. The Grand also offers<br> 
                better-than-Vegas odds for all the games you play.<br>
            </p>
        </div>
        <div class="main-foot"></div>
    </div>
</body>
</html>
