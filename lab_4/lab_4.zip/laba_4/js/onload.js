window.onload = function () {
    moveLogo();
};