<!DOCTYPE html>
<html>
<body>
    <div id="head">
        <div id="log">
            <a href="redirect.html"><img alt="Казино" id="logo" src="img/logo.png"></a>
        </div>
        <div class="loop">
            <a href="form.html"><img alt="Рулетка" src="img/backgrounds/header-1.jpg"></a>
        </div>
    </div>
</body>
</html>
